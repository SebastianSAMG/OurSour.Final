# Our Sour — Kotlin + Jetpack Compose + MVVM (modularizado)

El proyecto está separado en clases y archivos pequeños para facilitar el mantenimiento.

## Paquetes
- `model`: modelos de dominio y entidad local Room.
- `view`: contenedor de la aplicación, navegación, tema, componentes y pantallas.
- `viewmodel`: estado y lógica de presentación.
- `dao`: DAO de ingredientes frecuentes.
- `data`: configuración Room.

## Pantallas separadas
`BienvenidaScreen.kt`, `AccesoScreen.kt`, `InicioScreen.kt`, `IngredientesScreen.kt`, `RecetasScreen.kt`, `DetalleRecetaScreen.kt`, `CatalogoScreen.kt`, `CarroScreen.kt`, `DespachoScreen.kt`, `PedidosScreen.kt`, `AdministracionScreen.kt`.

## Antes de ejecutar
Agrega en `app/build.gradle.kts` dependencias compatibles con las versiones de tu proyecto:
```kotlin
implementation(platform("androidx.compose:compose-bom:<version>"))
implementation("androidx.activity:activity-compose:<version>")
implementation("androidx.compose.ui:ui")
implementation("androidx.compose.ui:ui-tooling-preview")
implementation("androidx.compose.material3:material3")
implementation("androidx.compose.material:material-icons-extended")
implementation("androidx.lifecycle:lifecycle-viewmodel-compose:<version>")
implementation("androidx.navigation:navigation-compose:<version>")
implementation("androidx.room:room-runtime:<version>")
implementation("androidx.room:room-ktx:<version>")
ksp("androidx.room:room-compiler:<version>")
```
Activa el plugin KSP compatible con Kotlin. Las versiones deben coincidir con tu proyecto Android.

## Integración backend
Esta versión usa datos de demostración en el ViewModel. Retrofit, JWT y endpoints reales deben conectarse después de revisar las clases/controladores del backend de tu compañero. El pago es solo simulado.

## Lector QR
Desde Inicio, pulsa **Escanear código QR** y luego el botón de escaneo. La pantalla solicita CAMERA mediante Activity Result API antes de abrir ZXing Android Embedded 4.3.0. Solo admite QR_CODE; el contenido se presenta como texto sin ejecutar enlaces ni almacenar datos en Room. Si rechazas el permiso, puedes abrir Ajustes y volver a intentar. El ViewModel conserva el resultado durante cambios de configuración. La pantalla y el botón Atrás permiten volver a Inicio.

### Archivos modificados
- `app/build.gradle.kts`: dependencia ZXing.
- `app/src/main/AndroidManifest.xml`: permiso CAMERA y características opcionales de cámara.
- `app/src/main/java/com/oursour/view/pantallas/InicioScreen.kt`: acceso al lector.
- `app/src/main/java/com/oursour/view/OurSourApp.kt`: ruta QR y corrección de importación dp preexistente.
- `app/src/main/java/com/oursour/viewmodel/OurSourViewModel.kt`: ruta, estado y operaciones QR.
- `app/src/main/java/com/oursour/view/pantallas/LectorQRScreen.kt`: nueva pantalla, permisos y lectura.

### Pruebas manuales pendientes
En Android Studio sincroniza Gradle y ejecuta en un dispositivo con cámara. Verifica: permiso concedido, rechazado, rechazo permanente y recuperación desde Ajustes; lectura de QR de texto/URL (sin abrir URL); rechazo de EAN/Code128; cancelación; nuevo escaneo; regreso a Inicio; dispositivo sin cámara. No se ha compilado ni probado en dispositivo en el entorno de edición.
