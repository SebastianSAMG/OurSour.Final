package com.oursour.view.pantallas

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.zxing.client.android.Intents
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.oursour.view.componentes.BotonPrincipal
import com.oursour.view.componentes.BotonSecundario
import com.oursour.view.componentes.TituloPantalla
import com.oursour.view.tema.TextoPrincipal
import com.oursour.view.tema.TextoSecundario
import com.oursour.viewmodel.OurSourViewModel
import com.oursour.viewmodel.Pantalla

@Composable
fun LectorQRScreen(vm: OurSourViewModel, contenido: String?, estado: String?) {
    val contexto = LocalContext.current
    val escaner = rememberLauncherForActivityResult(ScanContract()) { resultado ->
        val valor = resultado.contents
        when {
            resultado.originalIntent?.getBooleanExtra(Intents.Scan.MISSING_CAMERA_PERMISSION, false) == true ->
                vm.actualizarEstadoQR("Permiso de cámara no concedido.")
            valor == null -> vm.actualizarEstadoQR("Escaneo cancelado o no completado.")
            resultado.formatName != ScanOptions.QR_CODE ->
                vm.actualizarEstadoQR("Solo se admiten códigos QR.")
            else -> vm.registrarLecturaQR(valor)
        }
    }

    fun abrirCamara() {
        val opciones = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("Apunta la cámara hacia un código QR")
            .setBeepEnabled(false)
            .setOrientationLocked(false)
        try {
            escaner.launch(opciones)
        } catch (e: Exception) {
            vm.actualizarEstadoQR("No se pudo abrir el lector QR.")
        }
    }

    val permisoCamara = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { concedido ->
        if (concedido) abrirCamara()
        else vm.actualizarEstadoQR("Permiso de cámara no concedido. Puedes habilitarlo en Ajustes.")
    }

    BackHandler { vm.navegar(Pantalla.INICIO) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TituloPantalla("Lector de códigos QR")
        Text("Permite el acceso a la cámara para leer exclusivamente códigos QR.", color = TextoSecundario)
        BotonPrincipal("Escanear código QR") {
            vm.actualizarEstadoQR(null)
            if (!contexto.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
                vm.actualizarEstadoQR("El dispositivo no dispone de cámara.")
            } else if (ContextCompat.checkSelfPermission(contexto, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
                abrirCamara()
            } else {
                permisoCamara.launch(Manifest.permission.CAMERA)
            }
        }
        estado?.let { Text(it, color = TextoSecundario) }
        contenido?.let {
            Text("Contenido del QR:", color = TextoPrincipal)
            SelectionContainer { Text(it, color = TextoPrincipal) }
        }
        if (estado?.startsWith("Permiso de cámara no concedido") == true) {
            BotonSecundario("Abrir ajustes de permisos") {
                contexto.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", contexto.packageName, null)))
            }
        }
        BotonSecundario("Volver al inicio") { vm.navegar(Pantalla.INICIO) }
    }
}
